import TravelConcierge from './components/TravelConcierge';

function App() {
  return <TravelConcierge />;
}

export default App;
